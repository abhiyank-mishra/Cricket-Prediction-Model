This zip archive contains data files from Cricsheet in JSON format. This
archive contains 37 male Hyderabad (India) matches.


The JSON data files contained in this zip file are version 1.0.0, and 1.1.0
files. You can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/hyderabad_(india)_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2023-10-21 - club - SMA - male - 1383491 - Mizoram vs Hyderabad (India)
2023-10-19 - club - SMA - male - 1383472 - Chhattisgarh vs Hyderabad (India)
2022-10-14 - club - SMA - male - 1332956 - Hyderabad (India) vs Goa
2022-10-12 - club - SMA - male - 1332938 - Hyderabad (India) vs Puducherry
2022-10-11 - club - SMA - male - 1332920 - Punjab vs Hyderabad (India)
2021-11-20 - club - SMA - male - 1280300 - Hyderabad (India) vs Tamil Nadu
2021-11-18 - club - SMA - male - 1280299 - Hyderabad (India) vs Gujarat
2021-11-09 - club - SMA - male - 1280288 - Hyderabad (India) vs Uttar Pradesh
2021-11-06 - club - SMA - male - 1280249 - Chandigarh vs Hyderabad (India)
2021-11-05 - club - SMA - male - 1280230 - Hyderabad (India) vs Uttarakhand
2021-11-04 - club - SMA - male - 1280210 - Saurashtra vs Hyderabad (India)
2021-01-18 - club - SMA - male - 1244386 - Hyderabad (India) vs Jharkhand
2021-01-16 - club - SMA - male - 1244366 - Hyderabad (India) vs Tamil Nadu
2021-01-14 - club - SMA - male - 1244349 - Hyderabad (India) vs Bengal
2021-01-10 - club - SMA - male - 1244311 - Assam vs Hyderabad (India)
2019-11-15 - club - SMA - male - 1205808 - Arunachal Pradesh vs Hyderabad (India)
2019-11-14 - club - SMA - male - 1205799 - Hyderabad (India) vs Maharashtra
2019-11-12 - club - SMA - male - 1205781 - Chandigarh vs Hyderabad (India)
2019-11-11 - club - SMA - male - 1205755 - Himachal vs Hyderabad (India)
2019-11-09 - club - SMA - male - 1205745 - Hyderabad (India) vs Railways
2019-11-08 - club - SMA - male - 1205719 - Hyderabad (India) vs Punjab
2019-03-02 - club - SMA - male - 1157207 - Hyderabad (India) vs Uttarakhand
2019-02-28 - club - SMA - male - 1157190 - Hyderabad (India) vs Services
2019-02-25 - club - SMA - male - 1157156 - Hyderabad (India) vs Maharashtra
2019-02-24 - club - SMA - male - 1157138 - Hyderabad (India) vs Baroda
2019-02-22 - club - SMA - male - 1157122 - Hyderabad (India) vs Uttar Pradesh
2019-02-21 - club - SMA - male - 1157105 - Puducherry vs Hyderabad (India)
2018-01-14 - club - SMA - male - 1130712 - Tamil Nadu vs Hyderabad (India)
2018-01-12 - club - SMA - male - 1130701 - Hyderabad (India) vs Andhra
2018-01-11 - club - SMA - male - 1130689 - Karnataka vs Hyderabad (India)
2018-01-09 - club - SMA - male - 1130679 - Hyderabad (India) vs Goa
2018-01-08 - club - SMA - male - 1130670 - Hyderabad (India) vs Kerala
2016-01-10 - club - SMA - male - 902229 - Hyderabad (India) vs Tamil Nadu
2016-01-09 - club - SMA - male - 902207 - Hyderabad (India) vs Vidarbha
2016-01-04 - club - SMA - male - 902137 - Hyderabad (India) vs Gujarat
2016-01-03 - club - SMA - male - 902113 - Hyderabad (India) vs Himachal
2016-01-02 - club - SMA - male - 902089 - Bengal vs Hyderabad (India)
